function zoomIn() {
    document.getElementById('zoomImage').classList.add('zoomed');
}
function zoomOut() {
    document.getElementById('zoomImage').classList.remove('zoomed');
}


// function toggleDropdown(dropdown) {
//     dropdown.classList.toggle('active');
//   }



    // function toggleAdventureInfo() {
    //     const adventureInfo = document.querySelector('.adventure-info');
    //     adventureInfo.classList.toggle('show');
    // }

